import pandas as pd

texts = []
languages = []


english_sentences = [
    "Hello, how are you?", "Good morning!", "I love programming.", "This is a book.", "The weather is nice today."
]

french_sentences = [
    "Bonjour, comment ça va ?", "Il fait beau aujourd'hui.", "J'aime lire des livres.", "Ceci est une table.", "Bonne journée !"
]

spanish_sentences = [
    "Hola, ¿cómo estás?", "Buenos días.", "Me gusta programar.", "Esto es un libro.", "El clima es agradable hoy."
]

german_sentences = [
    "Hallo, wie geht's?", "Guten Morgen!", "Ich liebe Programmieren.", "Das ist ein Buch.", "Das Wetter ist heute schön."
]

italian_sentences = [
    "Ciao, come stai?", "Buongiorno!", "Amo programmare.", "Questo è un libro.", "Il tempo è bello oggi."
]

turkish_sentences = [
    "Merhaba, nasılsın?", "Günaydın!", "Programlamayı seviyorum.", "Bu bir kitap.", "Bugün hava güzel."
]


urdu_sentences = [
    "ہیلو، آپ کیسے ہیں؟", "صبح بخیر!", "مجھے پروگرامنگ پسند ہے۔", "یہ ایک کتاب ہے۔", "آج موسم اچھا ہے۔"
]

arabic_sentences = [
    "مرحبًا، كيف حالك؟", "صباح الخير!", "أنا أحب البرمجة.", "هذا كتاب.", "الطقس جميل اليوم."
]

japanese_sentences = [
    "こんにちは、お元気ですか？", "おはようございます！", "私はプログラミングが大好きです。", "これは本です。", "今日はいい天気ですね。"
]

korean_sentences = [
    "안녕하세요, 어떻게 지내세요?", "좋은 아침입니다!", "저는 프로그래밍을 좋아합니다.", "이것은 책입니다.", "오늘 날씨가 좋습니다."
]

for i in range(70):  # 10 languages * 5 sentences * 70 = 3500 entries
    for sentence in english_sentences:
        texts.append(sentence)
        languages.append('English')
    for sentence in french_sentences:
        texts.append(sentence)
        languages.append('French')
    for sentence in spanish_sentences:
        texts.append(sentence)
        languages.append('Spanish')
    for sentence in german_sentences:
        texts.append(sentence)
        languages.append('German')
    for sentence in italian_sentences:
        texts.append(sentence)
        languages.append('Italian')
    for sentence in turkish_sentences:
        texts.append(sentence)
        languages.append('Turkish')
    for sentence in urdu_sentences:
        texts.append(sentence)
        languages.append('Urdu')
    for sentence in arabic_sentences:
        texts.append(sentence)
        languages.append('Arabic')
    for sentence in japanese_sentences:
        texts.append(sentence)
        languages.append('Japanese')
    for sentence in korean_sentences:
        texts.append(sentence)
        languages.append('Korean')
        
        print(f"Length of texts: {len(texts)}")
print(f"Length of languages: {len(languages)}")

df = pd.DataFrame({'text': texts, 'language': languages})

df.to_csv('big_language_dataset.csv', index=False)

print(" Dataset created successfully with", len(df), "rows!")
print(" Dataset saved as 'big_language_dataset.csv'")
print("🔍 Dataset creation complete!")