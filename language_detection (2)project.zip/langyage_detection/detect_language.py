import joblib
model = joblib.load('language_detector.pkl')

while True:
    text = input("Enter a sentence (or type 'exit' to quit): ")
    if text.lower() == 'exit':
        break
    prediction = model.predict([text])
    print(f"🌎 Detected language: {prediction[0]}")
    print("🔍 Prediction complete!")