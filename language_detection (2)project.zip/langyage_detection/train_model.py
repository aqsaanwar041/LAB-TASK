import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
import joblib

df = pd.read_csv('big_language_dataset.csv')

X = df['text']
y = df['language']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print(f" Dataset loaded! Total examples: {len(df)}")
print(f" Training set size: {len(X_train)}")
model = make_pipeline(CountVectorizer(), LogisticRegression(max_iter=1000))

model.fit(X_train, y_train)
print("🔍 Model training in progress...")
accuracy = model.score(X_test, y_test)
print(f" Model trained with accuracy: {accuracy:.2f}")
print("🔍 Model training in progress...")
joblib.dump(model, 'language_detector.pkl')
print(" Model saved as language_detector.pkl")
print("🔍 Model training complete!")